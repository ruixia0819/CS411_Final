
--
-- Indexes for dumped tables
--

--
-- Indexes for table `have_histroy`
--
ALTER TABLE `have_histroy`
  ADD PRIMARY KEY (`his_id`),
  ADD KEY `user_name` (`user_name`),
  ADD KEY `restaurant_name` (`restaurant_name`);

--
-- Indexes for table `have_posts`
--
ALTER TABLE `have_posts`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `poster_name` (`poster_name`),
  ADD KEY `restaurant_name` (`restaurant_name`);

--
-- Indexes for table `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`user_name`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`address`),
  ADD UNIQUE KEY `address` (`address`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_name` (`user_name`),
  ADD UNIQUE KEY `user_email` (`user_email`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `have_histroy`
--
ALTER TABLE `have_histroy`
  MODIFY `his_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5579;
--
-- 使用表AUTO_INCREMENT `have_posts`
--
ALTER TABLE `have_posts`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incrementing user_id of each user, unique index', AUTO_INCREMENT=28;
--
-- 使用表AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incrementing user_id of each user, unique index', AUTO_INCREMENT=267;