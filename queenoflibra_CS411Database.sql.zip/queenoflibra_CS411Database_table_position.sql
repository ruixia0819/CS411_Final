
-- --------------------------------------------------------

--
-- 表的结构 `position`
--

CREATE TABLE `position` (
  `user_name` varchar(20) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `lat` double NOT NULL,
  `lng` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `position`
--

INSERT INTO `position` (`user_name`, `user_email`, `lat`, `lng`) VALUES
('erica', 'erica@illinois.edu', 40.1124887, -88.22707799999999),
('Rui', 'Rui@illinois.edu', 40.097854, -88.1891402),
('Midas', 'midas@illinois.edu', 40.1131463, -88.22645160000002),
('Anqi', 'anti@illinois.edu', 40.1130698, -88.2339571),
('Ruiqi', 'ruiqi@illinois.edu', 40.11380279999999, -88.22490519999997),
('Yang', 'yang@illinois.edu', 40.114153, -88.2328),
('bo', 'bo@illinois.edu', 40.1092101, -88.22722249999998),
('amenhotep', 'amenhotep@illinois.edu', 40.1082918, -88.22923679999997),
('rioxiarui', 'rioxiarui@illinois.edu', 40.1143782, -88.2252288),
('rioanqi', 'rioanqi@illinois.edu', 40.1141566, -88.225157),
('dingwei', 'dingwei@illinois.edu', 40.114295999999996, -88.2326437),
('qor', '81450508@XLZM.com', 40.1143976, -88.22523009999999),
('hmiy', '73298773@XLZM.com', 40.1124775, -88.2272418),
('hahahahahahaha', 'kjlhkjljljkj@gmail.com', 40.112481599999995, -88.22728169999999),
('demo1', 'demo1@illnois.edu', 40.1124782, -88.227055),
('demo7', 'demo7@illinois.edu', 40.11334, -88.22013099999998),
('demo6', 'demo6@illinois.edu', 40.1143645, -88.22520589999999),
('demo2', 'demo2@email.com', 40.115175, -88.221877),
('demo3', 'demo3@email.com', 40.1130698, -88.2339571),
('demo9', 'demo9@illinois.edu', 40.114153, -88.2328),
('xiaruirui', 'xiaruirui@illinois.edu', 40.114362299999996, -88.22519419999999),
('demo8', 'demo8@illinois.edu', 40.1148898, -88.22801729999998),
('demo10', 'demo10@illinois.edu', 40.1124997, -88.2269172),
('demo12', 'demo12@illnois.edu', 40.114362299999996, -88.2251982),
('Rey', 'rey@illinois.edu', 40.1143639, -88.2252084);
