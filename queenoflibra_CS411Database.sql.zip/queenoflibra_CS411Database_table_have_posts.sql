
-- --------------------------------------------------------

--
-- 表的结构 `have_posts`
--

CREATE TABLE `have_posts` (
  `post_id` int(11) NOT NULL COMMENT 'auto incrementing user_id of each user, unique index',
  `poster_name` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'user''s name, unique',
  `time_stamp` varchar(64) DEFAULT NULL,
  `restaurant_name` varchar(64) DEFAULT NULL,
  `attenders` varchar(64) DEFAULT NULL,
  `message` varchar(64) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `poster_email` varchar(64) DEFAULT NULL,
  `type` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `have_posts`
--

INSERT INTO `have_posts` (`post_id`, `poster_name`, `time_stamp`, `restaurant_name`, `attenders`, `message`, `number`, `poster_email`, `type`) VALUES
(1, 'erica', '23:19 4/25/2017', 'Wedge Tequila Bar &amp; Grill', 'rioxiarui,', 'Hey I am going to Wedge Tequila Bar &amp; Grill. Come join me!', 1, 'erica@illinois.edu', 1),
(2, 'demo2', '0:38 4/26/2017', 'Azzip Pizza', NULL, 'like it', 1, 'demo2@email.com', 1),
(3, 'demo6', '1:33 4/26/2017', 'Papa Del’s Pizza', 'demo7,', 'Hey I am going to Papa Del’s Pizza. Come join me!', 1, 'demo6@illinois.edu', 1),
(4, 'demo7', '1:34 4/26/2017', 'V Picasso', NULL, 'Join me!', 1, 'demo7@illinois.edu', 1),
(5, 'demo2', '1:34 4/26/2017', 'Jupiter’s Pizzeria and Billiards', NULL, ':)', 1, 'demo2@email.com', 1),
(6, 'demo6', '1:35 4/26/2017', 'Nando Milano Trattoria', NULL, 'Hey I am going to Nando Milano Trattoria. Come join me!', 1, 'demo6@illinois.edu', 1),
(19, 'demo8', '2:12 4/26/2017', 'Woori Jib Restaurant', NULL, 'Hey I am going to Woori Jib Restaurant. Come join me!', 1, 'demo8@illinois.edu', 1),
(8, 'demo6', '1:38 4/26/2017', 'Azzip Pizza', NULL, 'Hey I am going to Azzip Pizza. Come join me!', 1, 'demo6@illinois.edu', 1),
(9, 'demo2', '1:39 4/26/2017', 'The Red Herring Vegetarian Restaurant', NULL, ':(', 1, 'demo2@email.com', 1),
(10, 'demo7', '1:39 4/26/2017', 'Burrito King', NULL, 'Hey I am going to Burrito King. Come join me!', 1, 'demo7@illinois.edu', 1),
(20, 'demo10', '2:15 4/26/2017', 'Sitara', NULL, 'Hey I am going to Sitara. Come join me!', 1, 'demo10@illinois.edu', 1),
(26, 'Rey', '4:2 4/26/2017', 'South China Restaurant', NULL, 'who wants to join me at South China Restaurant?', 1, 'rey@illinois.edu', 1),
(27, 'demo1', '13:56 4/26/2017', 'A-Ri-Rang', NULL, 'Hey I am going to A-Ri-Rang. Come join me!', 1, 'demo1@illnois.edu', 1),
(23, 'erica', '3:13 4/26/2017', 'Rainbow Garden', NULL, 'anyone wanna join?', 1, 'erica@illinois.edu', 1),
(16, 'demo3', '1:47 4/26/2017', 'A-Ri-Rang', 'demo1,demo1,', 'like it', 1, 'demo3@email.com', 1),
(17, 'demo9', '1:49 4/26/2017', 'Pizzeria Antica', NULL, 'Hey I am going to Pizzeria Antica. Come join me!', 1, 'demo9@illinois.edu', 1);
